import numpy as np
from vpython import *
import matplotlib.pyplot as plt
import random

e=1.602176634E-19#基本電荷量
R0=1.2E-15#等下換算原子核半徑的基準

def R(A):#取得原子核半徑
    return R0*A**(1/3)

q_au=79*e#金的電量
q_alpha=2*e#alpha的電量
amu=1.66053907E-27
k=8.9875517873681764E9#庫倫力那個常數
r_alpha, m_alpha = R(4), 4*amu      # 氦原子核半徑、質量
r_au, m_au = R(197), 197*amu  # 金原子核半徑、質量
v0 = vec(0, 0, -1.6E7)  # 氦原子核初速度
radius_of_au=1.442E-10#金原子在晶格堆積中的半徑
t, dt = 0, 1E-19    # 時間, 時間間隔（時間間隔要在1E-11以下）
#b_const=4.66476505182E40#先不用理他
b_const=k*q_alpha*q_au/(0.5*2.56*4*1.66053907*1E-13)#用於理論計算用的常數
N=100#alpha粒子數
N_au=25
#撞擊參數數據1
'''
outer_b = 2E-13#撞擊參數外徑
inner_b=1E-13#撞擊參數內徑
start_z=0.00799999999949
'''

#撞擊參數數據2
'''
outer_b = 1E-13#撞擊參數外徑
inner_b=1E-14#撞擊參數內徑
start_z=0.00799999999981
'''
'''
#撞擊參數3
outer_b = 5E-13#撞擊參數外徑
inner_b=1E-14#撞擊參數內徑
start_z=0.0009999999988

'''
'''
#撞擊參數4
outer_b = 5E-13#撞擊參數外徑
inner_b=1E-14#撞擊參數內徑
start_z=0.00099999999308
'''

#撞擊參數5
outer_b = 5E-10#撞擊參數外徑
inner_b=5E-14#撞擊參數內徑
start_z=4E-10

'''
#撞擊參數6
outer_b = 1E-13#撞擊參數外徑
inner_b=8E-14#撞擊參數內徑
start_z=4E-10
'''
class alpha:
    #alpha粒子基本設定
    m=m_alpha
    r=r_alpha
    v=v0
    q=q_alpha
    a=0
    def init(self):
        #沒什麼特別意義
        self.pos=vec(0,0,0)

class au:
    #au基本參數設定
    pos=vec(0,0,0)
    m=m_au
    r=r_au
    q=q_au
    def init(self):
        pass

#紀錄散射後位置
x_pos_array=np.array([])
y_pos_array=np.array([])

#紀錄散射角在極座標上的分布
theta_x_array=np.array([])
theta_y_array=np.array([])

#記錄理論散射角在極座標上分布
radius_array=np.array([])
bx_array=np.array([])
by_array=np.array([])

#記錄實驗散射角
angle_list=[]

alphas=np.array([])#儲存所有alpha粒子
check_alphas=np.ones(int(N))#確認粒子是否已結束散射
reverse_alphas=np.zeros(int(N))#確認粒子是否已折返

initial_x_pos_array=np.array([])
initial_y_pos_array=np.array([])
r_au=1.44E-10
au1=au()#生成金粒子
aus = np.array([au1])
levels = 1
au_pos = [vec(0,0,0)]
outer = [vec(0,0,0)]
R_au = 1.44e-10
for i in range(N_au): #生成出 n 層金原子
    tmp_list = [] #暫時存放預計生成金原子的位置
    for partical in outer: #從最外層開始向外生成金原子
        tmp_vec = partical #取得最外層金原子的位置
        pos = tmp_vec+vec(sqrt(2)*R_au,sqrt(2)*R_au,0)#生成四個方向的位置
        if pos not in au_pos and pos not in outer and pos not in tmp_list: #判斷是否重複
            tmp_list += [pos]
            au_pos.append(pos)

        pos = tmp_vec+vec(-sqrt(2)*R_au,sqrt(2)*R_au,0)
        if pos not in au_pos and pos not in outer and pos not in tmp_list: #判斷是否重複
            tmp_list += [pos]
            au_pos.append(pos)

        pos = tmp_vec+vec(sqrt(2)*R_au,-sqrt(2)*R_au,0)
        if pos not in au_pos and pos not in outer and pos not in tmp_list: #判斷是否重複
            tmp_list += [pos]
            au_pos.append(pos)

        pos = tmp_vec+vec(-sqrt(2)*R_au,-sqrt(2)*R_au,0)
        if pos not in au_pos and pos not in outer and pos not in tmp_list: #判斷是否重複
            tmp_list += [pos]
            au_pos.append(pos)
    outer = tmp_list

au_pos_x=[]
au_pos_y=[]
for pos in au_pos:
    new_au = au()
    new_au.pos = pos
    au_pos_x.append(pos.x)
    au_pos_y.append(pos.y)
    aus = np.append(aus,[new_au])

for i in range(N):#生成alpha粒子並存入陣列
    #以極座標隨機生成alpha粒子初始位置
    theta=random.uniform(0,2*pi)
    radius=sqrt(random.random())*(outer_b-inner_b)+inner_b
    #radius=random.uniform(inner_b,outer_b)
    #計算理論散射角並儲存其在極座標上分布
    scatter_theta=2*atan(2*b_const/(2*radius))
    bx_array=np.append(bx_array,[cos(scatter_theta)])
    by_array=np.append(by_array,[sin(scatter_theta)])

    #生成alpha粒子，設定初始位置
    new_alpha=alpha()
    new_alpha.pos=vec(radius*cos(theta), radius*sin(theta), start_z)
    alphas=np.append(alphas,[new_alpha])

    initial_x_pos_array=np.append(initial_x_pos_array,[new_alpha.pos.x])
    initial_y_pos_array=np.append(initial_y_pos_array,[new_alpha.pos.y])
    

finished_alpha=0#完成散射的粒子數
while(finished_alpha<N):
    for i in range(N):
        if check_alphas[i]:#確認粒子還沒散射完成
            # 計算氦原子核所受合力, 更新氦原子核加速度、速度、位置
            sigma_F=vec(0,0,0)
            for j in range(len(aus)):
                sigma_F+=k*aus[j].q*alphas[i].q / mag2(alphas[i].pos-aus[j].pos) * norm((alphas[i].pos-aus[j].pos))
         
            alphas[i].a = sigma_F/alphas[i].m
            alphas[i].v += alphas[i].a*dt
            alphas[i].pos += alphas[i].v*dt
            #print(mag(alphas[i].pos))

            #檢查粒子是否散射折返
            if alphas[i].v.z>=0:
                reverse_alphas[i]=1#標示已散射完成
            if mag(alphas[i].pos)>2E-8 or (alphas[i].pos.z>0 and mag(alphas[i].pos)>2E-8 and reverse_alphas[i]) :#散射完成條件  不用理後面這段or abs(alphas[i].pos.y)>2
                finished_alpha+=1#已完成散射粒子數加一
                check_alphas[i]=0#標示該粒子已散射完成
                costheta=dot(alphas[i].v,v0)/(mag(alphas[i].v)*mag(v0))#計算散射角
                #print(costheta)
                angle_list.append(acos(costheta))#儲存實驗散射角
                #紀錄散射角在極座標上分布
                theta_x_array=np.append(theta_x_array,[costheta])
                theta_y_array=np.append(theta_y_array,[sin(acos(costheta))])

                #紀錄散射位置分布
                x_pos_array=np.append(x_pos_array,[alphas[i].pos.x])
                y_pos_array=np.append(y_pos_array,[alphas[i].pos.y]) 
                

angle_list.sort()#排序散射角分布，作為等下散射角機率計算用
#print(angle_list)

def cumulative_number_of_particles(angle_list):#計算大於某一角度散射角分布機率
    d_theta=pi/2/100000#角度切割最小單位
    current_theta=0#當前角度
    #min_theta=min(angle_list)
    cumulative_angle_list=[]
    current_pos=0
    #用兩個值去判讀小於某一角度目前累積粒子數
    for i in range(100000):
        current_theta+=d_theta
        try:
            while(angle_list[current_pos]<=current_theta):
                if current_pos<=(len(angle_list)-1):
                    current_pos+=1
        except:
            pass
        #print(current_pos)
        #反過來計算大於某一角度機率
        cumulative_angle_list.append((N-current_pos)/N)
        
        #節省計算量，當已統計完所有粒子即自動補完角度分布機率的array
        if current_pos==(len(angle_list)):
            for j in range(100000-i-1):
                cumulative_angle_list.append((N-current_pos)/N)
            break
        
    return cumulative_angle_list

#call上面的function，產生實驗散射角機率分布的list
angle_y_coord=cumulative_number_of_particles(angle_list)
angle_x_coord=[i*pi/200000 for i in range(100000)]

size=[0.01*i for i in range(N)]#修正畫點大小
size_cumu=[0.01*i for i in range(100000)]#修正畫點大小

#繪製散射角大於某一角度的機率分布，某一角度為x軸
plt.figure(dpi=250)#提高繪圖解析度及大小
plt.plot(angle_x_coord,angle_y_coord)#,s=size_cumu
#plt.xlim(0,1)
plt.title("Probability Experimental")


def particles_per_volume_fcc(atom_radius):#計算面心立方堆積單位體積粒子數
    particles=4#一立方體內粒子數
    volume=((4*atom_radius)/sqrt(2))**3#立方體積
    return particles/volume

par_per_v_au=particles_per_volume_fcc(radius_of_au)#call上面的function來取得單位體積粒子數

x_p_v=np.arange(0.001,pi/2,0.01)#x軸角度產生
y_p_v=[]

#繪製理論散射角機率分布
for i in x_p_v:
    y_p_v.append(par_per_v_au*35000*radius_of_au*pi*((0.5*b_const)**2)*((1/(tan(i/2))**2)))

plt.figure(dpi=250)
plt.plot(x_p_v,y_p_v)
#plt.xlim(0,1)
#plt.ylim(0,1)
plt.title("Probability Theoretical")
plt.show()


#繪製實驗散射角分布
plt.figure(dpi=250)
plt.scatter(theta_x_array,theta_y_array,s=size)
#plt.xlim(0,1)
#plt.ylim(0,1)
plt.title("Experimental Angle Distribution")


#繪製理論散射角分布
plt.figure(dpi=250)
plt.scatter(bx_array,by_array,s=size)
#plt.xlim(0.96,1)
#plt.ylim(0,0.3)
plt.title("Theoretical Angle Distribution")
plt.show()


#繪製散射xy分布
plt.figure(dpi=250)
plt.scatter(x_pos_array,y_pos_array,s=size)
plt.title("x-y distrbution")
plt.show()


#繪製粒子初始生成xy分布
size=[1*i for i in range(N)]#修正畫點大小
plt.figure(dpi=250)
plt.scatter(initial_x_pos_array,initial_y_pos_array,s=size)
plt.title("particles generating x-y distrbution")
plt.show()

size=[1*i for i in range(len(aus)-1)]
print(len(au_pos_x))
plt.figure(dpi=250)
plt.scatter(au_pos_x,au_pos_y, s=size)
plt.show()

def particles_per_volume_fcc(atom_radius):#計算面心立方堆積單位體積粒子數
    particles=4#一立方體內粒子數
    volume=((4*atom_radius)/sqrt(2))**3#立方體積
    return particles/volume

par_per_v_au=particles_per_volume_fcc(radius_of_au)#call上面的function來取得單位體積粒子數

x_p_v=np.arange(0.001,pi/2,0.01)#x軸角度產生
y_p_v=[]

#繪製理論散射角機率分布
for i in x_p_v:
    y_p_v.append(par_per_v_au*20*radius_of_au*pi*((0.5*b_const)**2)*((1/(tan(i/2))**2)))

plt.figure(dpi=250)
plt.plot(x_p_v,y_p_v)
plt.xlim(0,0.5)
plt.ylim(0,1)
plt.title("Probability Theoretical")
plt.show()