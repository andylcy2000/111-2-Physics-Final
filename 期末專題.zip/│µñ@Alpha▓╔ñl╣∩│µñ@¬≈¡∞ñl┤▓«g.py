import numpy as np
from vpython import *
import matplotlib.pyplot as plt
import random

e=1.602176634E-19#基本電荷量
R0=1.2E-15#等下換算原子核半徑的基準

def R(A):#取得原子核半徑
    return R0*A**(1/3)

def angualr_momentum(r,m,v): #計算角動量
    return mag(m*cross(r,v))

q_au=79*e#金的電量
q_alpha=2*e#alpha的電量
amu=1.66053907E-27
k=8.9875517873681764E9#庫倫力那個常數
r_alpha, m_alpha, c1 = R(4), 4*amu, color.red      # 氦原子核半徑、質量、顏色
r_au, m_au, c2 = R(197), 197*amu, color.yellow  # 金原子核半徑、質量、顏色
v0 = vec(0, 0, -1.6E7)  # 氦原子核初速度
#Kinetic=1E5*1.6E-19
#v0=vec(0,0,-sqrt(Kinetic*2/m_alpha))

t, dt = 0, 1E-20    # 時間, 時間間隔（時間間隔要在1E-11以下）
#b_const=4.66476505182E40#先不用理他
b_const=k*q_alpha*q_au/(0.5*2.56*4*1.66053907*1E-13)
#b_const=k*q_alpha*q_au/(1E5*1.6E-19)
N_alpha= 1#alpha粒子數

'''
#撞擊參數5
outer_b = 1E-11#撞擊參數外徑
inner_b= 2E-12#撞擊參數內徑
start_z= 6E-11
'''

#撞擊參數6
outer_b = 3E-10#撞擊參數外徑
inner_b=5E-12#撞擊參數內徑
start_z=1E-11


class alpha:
    #alpha粒子基本設定
    m=m_alpha
    r=r_alpha
    q=q_alpha
    pos=vec(0,0,0)
    v=v0
    a=0
    d = 0
    def __init__(self):
        #沒什麼特別意義
        pass

class au:
    #au基本參數設定
    pos=vec(0,0,0)
    m=m_au
    r=r_au
    q=q_au
    def __init__(self):
        pass

#紀錄散射後位置
x_pos_array=np.array([])
y_pos_array=np.array([])

#紀錄散射角在極座標上的分布
theta_x_array=np.array([])
theta_y_array=np.array([])

#記錄理論散射角在極座標上分布
radius_array=np.array([])
bx_array=np.array([])
by_array=np.array([])


angle_list=[]

times = 0
L = np.array([])
K = np.array([])
U = np.array([])
E = np.array([])
D = np.array([])
B = np.array([])

alphas=np.array([])#儲存所有alpha粒子
check_alphas=np.ones(int(N_alpha))#確認粒子是否已結束散射
reverse_alphas=np.zeros(int(N_alpha))

#initial_x_pos_array=np.array([])
#initial_y_pos_array=np.array([])

au1=au()#生成金粒子
for i in range(N_alpha):#生成alpha粒子並存入陣列
    #以極座標隨機生成alpha粒子初始位置
    theta=random.uniform(0,2*pi)
    radius=sqrt(random.random())*(outer_b-inner_b)+inner_b
    #radius=random.uniform(inner_b,outer_b)
    scatter_theta=2*atan(2*b_const/(2*radius))
    bx_array=np.append(bx_array,[cos(scatter_theta)])
    by_array=np.append(by_array,[sin(scatter_theta)])
    #print(radius)
    #print(scatter_theta)

    #儲存理論散射角在即座標上的分布
    #bx_array=np.append(bx_array,[cos(2/atan((radius*m_alpha*mag(v0)**2)/(k*q_alpha*q_au)))])
    #by_array=np.append(by_array,[sin(2/atan((radius*m_alpha*mag(v0)**2)/(k*q_alpha*q_au)))])

    #radius_array=np.append(radius_array,[radius])

    #生成alpha粒子，設定初始位置
    new_alpha=alpha()
    new_alpha.pos=vec(radius*cos(theta), radius*sin(theta), start_z)
    new_alpha.d = radius
    alphas=np.append(alphas,[new_alpha])

    #initial_x_pos_array=np.append(initial_x_pos_array,[new_alpha.pos.x])
    #initial_y_pos_array=np.append(initial_y_pos_array,[new_alpha.pos.y])

finished_alpha=0#完成散射的粒子數
while(finished_alpha<N_alpha):
    for i in range(N_alpha):
        if check_alphas[i]:#確認粒子還沒散射完成
            # 計算氦原子核所受合力, 更新氦原子核加速度、速度、位置
            F = k*au1.q*alphas[i].q / alphas[i].pos.mag2 * alphas[i].pos.norm()
            alphas[i].a = F/alphas[i].m
            alphas[i].v += alphas[i].a*dt
            alphas[i].pos += alphas[i].v*dt

            t += dt
            times += 1

            L = np.append(L,[angualr_momentum(alphas[i].pos - au1.pos,alphas[i].m,alphas[i].v)])#計算角動量
            K = np.append(K,[0.5*alphas[i].m*mag2(alphas[i].v)])#計算動能
            U = np.append(U,[k*q_alpha*q_au/mag(alphas[i].pos - au1.pos)])#計算位能

            #print(mag(alphas[i].pos))
            if alphas[i].v.z>=0:
                reverse_alphas[i]=1
            if mag(alphas[i].pos)>2E-9 or (alphas[i].pos.z>0 and mag(alphas[i].pos)>2E-9 and reverse_alphas[i]) :#散射完成條件
                finished_alpha+=1#已完成散射粒子數加一
                check_alphas[i]=0#標示該粒子已散射完成
                costheta=dot(alphas[i].v,v0)/(mag(alphas[i].v)*mag(v0))#計算散射角
                #print(costheta)
                angle_list.append(acos(costheta))
                #紀錄散射角在極座標上分布
                theta_x_array=np.append(theta_x_array,[costheta])
                theta_y_array=np.append(theta_y_array,[sin(acos(costheta))])
                
                vertical = sqrt(alphas[i].pos.x**2+alphas[i].pos.y**2)-alphas[i].d #計算垂直偏移
                D = np.append(D,[vertical]) #更新垂直偏移陣列
                B = np.append(B,alphas[i].d) #更新撞擊參數陣列
                '''
                if alphas[i].pos.z<-1:#還要再修正
                    x_pos_array=np.append(x_pos_array,[alphas[i].pos.x])
                    y_pos_array=np.append(y_pos_array,[alphas[i].pos.y])
                '''

angle_list.sort()
#print(angle_list)

def cumulative_number_of_particles(angle_list):
    d_theta=pi/2/100000
    current_theta=0
    #min_theta=min(angle_list)
    cumulative_angle_list=[]
    current_pos=0
    for i in range(100000):
        current_theta+=d_theta
        try:
            while(angle_list[current_pos]<=current_theta):
                if current_pos<=(len(angle_list)-1):
                    current_pos+=1
        except:
            pass
        #print(current_pos)
        cumulative_angle_list.append(current_pos)
        
        if current_pos==(len(angle_list)):
            for j in range(100000-i-1):
                cumulative_angle_list.append(current_pos)
            break
        
    return cumulative_angle_list

angle_y_coord=cumulative_number_of_particles(angle_list)

angle_x_coord=[i*pi/200000 for i in range(100000)]

size=[0.0001*i for i in range(N_alpha)]#修正畫點大小

size_cumu=[0.000001*i for i in range(100000)]
plt.figure(dpi=250)
# plt.scatter(angle_x_coord,angle_y_coord,s=size_cumu)
# plt.xlim(0,0.31)
'''
#繪製實驗散設分布

plt.scatter(theta_x_array,theta_y_array,s=size)
plt.xlim(0.96,1)
plt.ylim(0,0.3)
plt.title("experimental")
plt.show()

plt.figure(dpi=250)
plt.scatter(bx_array,by_array,s=size)#繪製理論散射分布
plt.xlim(0.96,1)
plt.ylim(0,0.3)
plt.title("theoretical")
'''
E = K+U #計算力學能


T = np.array([]) #時間陣列
for i in range(times): #計算出時間
    T = np.append(T,(i+1)*dt)
plt.scatter(T,L,s=2) #繪製角動量的趨勢圖
plt.show()
plt.scatter(T,K,s=5) #繪製動能的趨勢圖
plt.show()
plt.scatter(T,U,s=5) #繪製位能的趨勢圖
plt.show()
plt.scatter(T,E,s=5) #繪製力學能的趨勢圖
plt.show()

# plt.scatter(B,D)#繪製撞擊參數-垂直偏移的趨勢圖
# plt.show()

'''
print(bx_array)
print(by_array)
'''