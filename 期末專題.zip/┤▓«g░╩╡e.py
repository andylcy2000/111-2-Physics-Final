from vpython import *
import time
r1, m1, q1 = 0.4, 4, 2
r2, m2, q2 = 1, 197, 79
v0 = vec(10, 0, 0)
L, k = 40, 1
t, dt = 0, 1E-3
c2 = color.yellow

scene = canvas(title="Rutherford Scattering", width=800, height=600, x=0, y=0, center=vec(0, 0, 0), background=color.black)
au = sphere(pos=vec(0, 0, 0), radius=r2, m=m2, q=q2, color=c2)
n = 100
time.sleep(2)
for i in range(0, n+1, 1):
    alpha = sphere(pos=vec(-L/2 + r1, i/10, 0), radius=r1, m=m1, q=q1, v=v0, color=vec((n-i)/n, 0, i/n), make_trail=True)
    arrow_v = arrow(pos=alpha.pos, shaftwidth=0.5*r1, color=color.cyan)
    arrow_a = arrow(pos=alpha.pos, shaftwidth=0.5*r1, color=color.magenta)
    while(abs(alpha.pos.x) < L/2 and abs(alpha.pos.y) < L/2):
        rate(5000)
        F = k*alpha.q*au.q / alpha.pos.mag2 * alpha.pos.norm()
        alpha.a = F/alpha.m
        alpha.v += alpha.a*dt
        alpha.pos += alpha.v*dt
        arrow_v.pos = alpha.pos
        arrow_a.pos = alpha.pos
        arrow_v.axis = alpha.v
        arrow_a.axis = alpha.a
        t += dt
    arrow_v.visible = False
    arrow_a.visible = False
    print(i/10, alpha.pos.y - i/10)